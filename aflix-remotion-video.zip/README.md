# 🎬 Aflix Infotech – Remotion Motion Graphic Video

A **professional 24-second brand video** for Aflix Infotech built entirely with React + Remotion.
Exports as a full **1920×1080 MP4** — no After Effects needed.

---

## 📁 Project Structure

```
aflix-remotion/
├── src/
│   ├── index.ts                          ← Entry point
│   ├── Root.tsx                          ← Registers compositions
│   ├── utils/
│   │   ├── animations.ts                 ← Easing & animation helpers
│   │   └── brand.ts                      ← Colors, fonts, brand tokens
│   ├── components/
│   │   └── ParticleBackground.tsx        ← Shared animated background
│   └── compositions/
│       ├── AflixtVideo.tsx               ← Main composition (stitches scenes)
│       ├── SceneIntro.tsx                ← Scene 1: Logo reveal (4s)
│       ├── SceneServices.tsx             ← Scene 2: Services cards (5.3s)
│       ├── SceneStats.tsx                ← Scene 3: Stats + testimonial (5.3s)
│       ├── SceneProcess.tsx              ← Scene 4: How we work (5s)
│       └── SceneCTA.tsx                  ← Scene 5: CTA + contact (4.3s)
├── out/                                  ← Rendered video goes here
├── package.json
└── tsconfig.json
```

---

## 🚀 Quick Start

### Prerequisites
- **Node.js 18+** (download from nodejs.org)
- **npm** (comes with Node)
- A modern terminal (PowerShell, Terminal, VS Code terminal)

### Step 1 — Install dependencies
```bash
cd aflix-remotion
npm install
```
> This installs Remotion and React (~200MB, takes 1–2 min)

### Step 2 — Open Remotion Studio (Preview)
```bash
npm start
```
Then open **http://localhost:3000** in Chrome.
You'll see a frame-by-frame player with a timeline — scrub, pause, preview every scene!

### Step 3 — Export to MP4
```bash
npm run build
```
The exported video appears at **`out/aflix-video.mp4`** — share anywhere!

---

## 🎨 Customization Guide

### Change Brand Colors
Edit `src/utils/brand.ts`:
```ts
export const BRAND = {
  blue:   "#5b6ef5",   // ← Change to your hex
  purple: "#a78bfa",   // ← Change accent
  bg:     "#04060f",   // ← Background
  // ...
};
```

### Change Fonts
In `brand.ts`, edit `GOOGLE_FONTS_URL` to any Google Fonts URL, then update:
```ts
fontDisplay: "'YourFont', sans-serif",
fontBody:    "'YourBodyFont', sans-serif",
```

### Edit Scene Content

**Services** – edit the `SERVICES` array in `SceneServices.tsx`:
```ts
const SERVICES = [
  { icon: "⚡", title: "Your Service", desc: "Description...", tags: ["Tag1","Tag2"] },
  // ...
];
```

**Stats** – edit the `STATS` array in `SceneStats.tsx`:
```ts
const STATS = [
  { value: 100, suffix: "+", label: "Clients\nServed", color: BRAND.blue },
  // ...
];
```

**Testimonial** – edit the `TESTIMONIAL` object in `SceneStats.tsx`.

**CTA** – edit text directly in `SceneCTA.tsx`.

### Adjust Scene Timing
In `AflixtVideo.tsx`, change the duration constants:
```ts
const D_INTRO    = 120;  // frames (÷30 = seconds)
const D_SERVICES = 160;
// ...
```

### Change Video Resolution
In `AflixtVideo.tsx`:
```ts
export const VIDEO_WIDTH  = 1920;  // 1280 for HD, 1080 for square
export const VIDEO_HEIGHT = 1080;  // 1080 for HD, 1080 for square
```

---

## 📦 Export Options

### MP4 (default – best for sharing)
```bash
npm run build
```

### GIF (for social/web)
```bash
npx remotion render AflixtVideo out/aflix.gif
```

### Image Sequence (for editing in Premiere/DaVinci)
```bash
npx remotion render AflixtVideo out/frames/ --sequence
```

### Specific frame range (for a clip)
```bash
npx remotion render AflixtVideo out/clip.mp4 --frames=0-90
```

---

## 🌐 Where to Edit & Run This Online

| Platform | URL | Free? | Notes |
|---|---|---|---|
| **StackBlitz** | stackblitz.com | ✅ | Paste code, live preview |
| **CodeSandbox** | codesandbox.io | ✅ | Full Node support |
| **Remotion Cloud** | remotion.dev/cloud | Paid | Render in cloud, no GPU needed |
| **GitHub Codespaces** | github.com/codespaces | ✅ | Full dev environment |

For **StackBlitz**: Click "New Project" → "Node.js" → paste all files → `npm install && npm start`

---

## 🎬 Adding More Scenes

1. Create `src/compositions/SceneMyNew.tsx`
2. Import it in `AflixtVideo.tsx`
3. Add duration constant `const D_NEW = 90;`
4. Add `<AbsoluteFill>` with `sceneOpacity(...)` call

---

## 🔧 Troubleshooting

| Issue | Fix |
|---|---|
| `command not found: remotion` | Run `npm install` first |
| Blank screen in Studio | Check browser console, try Chrome |
| Font not loading | Check internet connection (Google Fonts CDN) |
| Export too slow | Normal — rendering 720 frames takes 3–8 min on CPU |
| MP4 won't play | Install VLC or use Chrome to open |

---

## 💡 Pro Tips

- **Add your real logo**: Export it as SVG and drop it into `SceneIntro.tsx`
- **Add real client metrics**: Update `STATS` values with verified numbers
- **Add background music**: Use `<Audio>` from Remotion — `import { Audio } from 'remotion'`
- **Add images**: Use `<Img>` from Remotion — handles remote/local images properly
- **Add Lottie animations**: Install `@remotion/lottie` for AE-exported animations

---

Made with ❤️ by Claude for **Aflix Infotech** — aflix.co.in
