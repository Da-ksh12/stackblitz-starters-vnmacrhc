// ─── Aflix Infotech Brand Constants ──────────────────────────────────────

export const BRAND = {
  // Core palette
  bg:         "#04060f",
  bgCard:     "rgba(255,255,255,0.04)",
  bgCardHov:  "rgba(91,110,245,0.1)",
  blue:       "#5b6ef5",
  purple:     "#a78bfa",
  blueGlow:   "rgba(91,110,245,0.35)",
  white:      "#ffffff",
  muted:      "rgba(255,255,255,0.45)",
  veryMuted:  "rgba(255,255,255,0.15)",
  border:     "rgba(255,255,255,0.08)",
  borderBlue: "rgba(91,110,245,0.4)",

  // Gradients
  gradMain:   "linear-gradient(135deg, #5b6ef5, #a78bfa)",
  gradText:   "linear-gradient(90deg, #ffffff, #a78bfa)",
  gradCard:   "linear-gradient(135deg, rgba(91,110,245,0.15), rgba(167,139,250,0.05))",

  // Typography (Google Fonts loaded via @remotion/google-fonts or inline @import)
  fontDisplay: "'Syne', sans-serif",
  fontBody:    "'Space Grotesk', sans-serif",
};

// Scene colours per service card
export const CARD_COLORS = [
  { accent: "#5b6ef5", glow: "rgba(91,110,245,0.25)",  bg: "rgba(91,110,245,0.08)"  },
  { accent: "#a78bfa", glow: "rgba(167,139,250,0.25)", bg: "rgba(167,139,250,0.08)" },
  { accent: "#38bdf8", glow: "rgba(56,189,248,0.25)",  bg: "rgba(56,189,248,0.08)"  },
  { accent: "#34d399", glow: "rgba(52,211,153,0.25)",  bg: "rgba(52,211,153,0.08)"  },
];

export const GOOGLE_FONTS_URL =
  "https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=Syne:wght@700;800&display=swap";
