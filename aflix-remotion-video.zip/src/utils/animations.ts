import { interpolate, Easing } from "remotion";

// ─── Custom easing shortcuts ───────────────────────────────────────────────
export const easeOutExpo = Easing.bezier(0.16, 1, 0.3, 1);
export const easeOutBack = Easing.bezier(0.34, 1.56, 0.64, 1);
export const easeInOutQuart = Easing.bezier(0.76, 0, 0.24, 1);
export const easeOutCubic = Easing.bezier(0.33, 1, 0.68, 1);

// ─── Fade in from 0→1 ─────────────────────────────────────────────────────
export const fadeIn = (frame: number, start: number, duration = 20) =>
  interpolate(frame, [start, start + duration], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing: easeOutCubic,
  });

// ─── Fade out from 1→0 ────────────────────────────────────────────────────
export const fadeOut = (frame: number, start: number, duration = 20) =>
  interpolate(frame, [start, start + duration], [1, 0], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing: easeInOutQuart,
  });

// ─── Slide up: translateY(px → 0) ─────────────────────────────────────────
export const slideUp = (frame: number, start: number, duration = 25, px = 60) =>
  interpolate(frame, [start, start + duration], [px, 0], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing: easeOutExpo,
  });

// ─── Scale from s0 → s1 ───────────────────────────────────────────────────
export const scaleFrom = (
  frame: number,
  start: number,
  duration = 25,
  s0 = 0.85,
  s1 = 1
) =>
  interpolate(frame, [start, start + duration], [s0, s1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing: easeOutBack,
  });

// ─── Stagger helper: returns start frame for nth item ─────────────────────
export const stagger = (baseStart: number, index: number, gap = 8) =>
  baseStart + index * gap;

// ─── Counter: animates 0 → target number ──────────────────────────────────
export const counter = (frame: number, start: number, duration: number, target: number) =>
  Math.round(
    interpolate(frame, [start, start + duration], [0, target], {
      extrapolateLeft: "clamp",
      extrapolateRight: "clamp",
      easing: easeOutExpo,
    })
  );

// ─── Width animator for progress bars / line reveals ─────────────────────
export const growWidth = (
  frame: number,
  start: number,
  duration = 40,
  from = 0,
  to = 1
) =>
  interpolate(frame, [start, start + duration], [from, to], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing: easeOutExpo,
  });

// ─── Rotate ───────────────────────────────────────────────────────────────
export const spin = (frame: number, start: number, duration = 60, degrees = 360) =>
  interpolate(frame, [start, start + duration], [0, degrees], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing: Easing.linear,
  });
