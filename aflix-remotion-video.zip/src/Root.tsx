import React from "react";
import { Composition } from "remotion";
import { AflixtVideo, VIDEO_FPS, VIDEO_HEIGHT, VIDEO_WIDTH, TOTAL_DURATION } from "./compositions/AflixtVideo";

export const Root: React.FC = () => {
  return (
    <>
      <Composition
        id="AflixtVideo"
        component={AflixtVideo}
        durationInFrames={TOTAL_DURATION}
        fps={VIDEO_FPS}
        width={VIDEO_WIDTH}
        height={VIDEO_HEIGHT}
        defaultProps={{}}
      />
    </>
  );
};
