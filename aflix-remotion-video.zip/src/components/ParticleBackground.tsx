import React from "react";
import { useCurrentFrame, useVideoConfig, interpolate } from "remotion";
import { BRAND } from "../utils/brand";

interface Particle {
  x: number;
  y: number;
  size: number;
  speed: number;
  opacity: number;
  color: string;
  phase: number;
}

const SEED_PARTICLES: Particle[] = Array.from({ length: 60 }, (_, i) => ({
  x: ((i * 137.508) % 100),
  y: ((i * 97.3) % 100),
  size: (i % 3) * 0.8 + 0.8,
  speed: (i % 5) * 0.003 + 0.002,
  opacity: (i % 4) * 0.08 + 0.06,
  color: i % 3 === 0 ? BRAND.blue : i % 3 === 1 ? BRAND.purple : "#38bdf8",
  phase: (i * 31.7) % (Math.PI * 2),
}));

const GRID_DOTS: { x: number; y: number }[] = [];
for (let gx = 0; gx <= 100; gx += 5)
  for (let gy = 0; gy <= 100; gy += 5)
    GRID_DOTS.push({ x: gx, y: gy });

export const ParticleBackground: React.FC<{ opacity?: number }> = ({
  opacity = 1,
}) => {
  const frame = useCurrentFrame();
  const { width, height } = useVideoConfig();

  return (
    <div
      style={{
        position: "absolute",
        inset: 0,
        overflow: "hidden",
        opacity,
      }}
    >
      {/* Subtle grid */}
      <svg
        style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }}
        viewBox={`0 0 ${width} ${height}`}
      >
        {GRID_DOTS.map((d, i) => (
          <circle
            key={i}
            cx={(d.x / 100) * width}
            cy={(d.y / 100) * height}
            r={1}
            fill={BRAND.blue}
            opacity={0.06}
          />
        ))}

        {/* Connecting lines for nearby particles */}
        {SEED_PARTICLES.map((a, i) =>
          SEED_PARTICLES.slice(i + 1, i + 4).map((b, j) => {
            const ax = ((a.x + Math.sin(frame * a.speed + a.phase) * 3) / 100) * width;
            const ay = ((a.y + Math.cos(frame * a.speed + a.phase) * 2) / 100) * height;
            const bx = ((b.x + Math.sin(frame * b.speed + b.phase) * 3) / 100) * width;
            const by = ((b.y + Math.cos(frame * b.speed + b.phase) * 2) / 100) * height;
            const dist = Math.hypot(ax - bx, ay - by);
            if (dist > 160) return null;
            return (
              <line
                key={`${i}-${j}`}
                x1={ax} y1={ay} x2={bx} y2={by}
                stroke={BRAND.blue}
                strokeWidth={0.5}
                opacity={(1 - dist / 160) * 0.12}
              />
            );
          })
        )}

        {/* Particles */}
        {SEED_PARTICLES.map((p, i) => {
          const px = ((p.x + Math.sin(frame * p.speed + p.phase) * 3) / 100) * width;
          const py = ((p.y + Math.cos(frame * p.speed + p.phase) * 2) / 100) * height;
          return (
            <circle
              key={i}
              cx={px}
              cy={py}
              r={p.size}
              fill={p.color}
              opacity={p.opacity + Math.sin(frame * 0.02 + p.phase) * 0.04}
            />
          );
        })}
      </svg>

      {/* Radial gradient overlay */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          background:
            "radial-gradient(ellipse 80% 60% at 50% 50%, transparent 40%, rgba(4,6,15,0.7) 100%)",
        }}
      />
    </div>
  );
};
