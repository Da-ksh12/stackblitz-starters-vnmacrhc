import React from "react";
import { useCurrentFrame, interpolate } from "remotion";
import { BRAND, CARD_COLORS, GOOGLE_FONTS_URL } from "../utils/brand";
import { fadeIn, fadeOut, slideUp, scaleFrom, growWidth, stagger, easeOutExpo } from "../utils/animations";
import { ParticleBackground } from "../components/ParticleBackground";

const SERVICES = [
  {
    icon: "⚡",
    title: "Software Development",
    desc: "Custom web & mobile applications built for scale, performance, and real business outcomes.",
    tags: ["React", "Node.js", "Mobile"],
  },
  {
    icon: "🤖",
    title: "CRM & Automation",
    desc: "Smart workflows and CRM systems that run your business operations 24/7 without manual effort.",
    tags: ["Workflow", "CRM", "Integration"],
  },
  {
    icon: "📈",
    title: "Digital Marketing",
    desc: "Data-driven growth strategies — SEO, ads, and content — that put Aflix clients ahead.",
    tags: ["SEO", "Ads", "Growth"],
  },
  {
    icon: "🌐",
    title: "Industry Verticals",
    desc: "Specialized solutions for Real Estate, Healthcare, E-commerce, and more sectors.",
    tags: ["Real Estate", "Healthcare", "E-com"],
  },
];

export const SceneServices: React.FC<{ localFrame: number }> = ({ localFrame }) => {
  const f = localFrame;

  const bgOp    = fadeIn(f, 0, 25);
  const headOp  = fadeIn(f, 10, 20);
  const headY   = slideUp(f, 10, 25, 30);
  const subOp   = fadeIn(f, 25, 20);

  const exitOp  = f > 130 ? fadeOut(f, 130, 20) : 1;

  return (
    <div
      style={{
        position: "absolute",
        inset: 0,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        background: BRAND.bg,
        opacity: exitOp,
        padding: "0 80px",
      }}
    >
      <style>{`@import url('${GOOGLE_FONTS_URL}');`}</style>
      <ParticleBackground opacity={bgOp * 0.6} />

      {/* Section label */}
      <div
        style={{
          fontFamily: BRAND.fontBody,
          fontSize: 12,
          letterSpacing: 5,
          color: BRAND.blue,
          textTransform: "uppercase",
          marginBottom: 16,
          opacity: headOp,
          transform: `translateY(${headY}px)`,
          position: "relative",
          zIndex: 2,
        }}
      >
        What We Build
      </div>

      {/* Headline */}
      <div
        style={{
          fontFamily: BRAND.fontDisplay,
          fontWeight: 800,
          fontSize: 52,
          color: BRAND.white,
          textAlign: "center",
          marginBottom: 8,
          letterSpacing: -1,
          opacity: headOp,
          transform: `translateY(${headY}px)`,
          position: "relative",
          zIndex: 2,
          lineHeight: 1.1,
        }}
      >
        Transforming Businesses with{" "}
        <span
          style={{
            background: BRAND.gradMain,
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
          }}
        >
          Technology
        </span>
      </div>

      <div
        style={{
          fontFamily: BRAND.fontBody,
          fontSize: 16,
          color: BRAND.muted,
          marginBottom: 50,
          opacity: subOp,
          position: "relative",
          zIndex: 2,
        }}
      >
        End-to-end digital solutions for modern businesses
      </div>

      {/* Cards grid */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(2, 1fr)",
          gap: 20,
          width: "100%",
          maxWidth: 960,
          position: "relative",
          zIndex: 2,
        }}
      >
        {SERVICES.map((svc, i) => {
          const cardStart = stagger(35, i, 12);
          const cardOp  = fadeIn(f, cardStart, 22);
          const cardY   = slideUp(f, cardStart, 25, 40);
          const barW    = growWidth(f, cardStart + 10, 30, 0, 1);
          const col     = CARD_COLORS[i];

          return (
            <div
              key={i}
              style={{
                background: BRAND.bgCard,
                border: `1px solid ${BRAND.border}`,
                borderRadius: 20,
                padding: "28px 28px 24px",
                opacity: cardOp,
                transform: `translateY(${cardY}px)`,
                position: "relative",
                overflow: "hidden",
              }}
            >
              {/* Card accent top bar */}
              <div
                style={{
                  position: "absolute",
                  top: 0,
                  left: 0,
                  height: 3,
                  width: `${barW * 100}%`,
                  background: `linear-gradient(90deg, ${col.accent}, transparent)`,
                  borderRadius: "20px 20px 0 0",
                }}
              />

              {/* Number */}
              <div
                style={{
                  position: "absolute",
                  top: 20,
                  right: 24,
                  fontFamily: BRAND.fontDisplay,
                  fontWeight: 800,
                  fontSize: 40,
                  color: col.accent,
                  opacity: 0.12,
                  lineHeight: 1,
                }}
              >
                {String(i + 1).padStart(2, "0")}
              </div>

              {/* Icon */}
              <div style={{ fontSize: 36, marginBottom: 14 }}>{svc.icon}</div>

              {/* Title */}
              <div
                style={{
                  fontFamily: BRAND.fontDisplay,
                  fontWeight: 700,
                  fontSize: 20,
                  color: BRAND.white,
                  marginBottom: 10,
                  letterSpacing: -0.3,
                }}
              >
                {svc.title}
              </div>

              {/* Description */}
              <div
                style={{
                  fontFamily: BRAND.fontBody,
                  fontSize: 13,
                  color: BRAND.muted,
                  lineHeight: 1.65,
                  marginBottom: 16,
                }}
              >
                {svc.desc}
              </div>

              {/* Tags */}
              <div style={{ display: "flex", gap: 8 }}>
                {svc.tags.map((tag, ti) => (
                  <div
                    key={ti}
                    style={{
                      background: col.bg,
                      border: `1px solid ${col.accent}30`,
                      borderRadius: 6,
                      padding: "3px 10px",
                      fontSize: 11,
                      fontFamily: BRAND.fontBody,
                      fontWeight: 500,
                      color: col.accent,
                      letterSpacing: 0.5,
                    }}
                  >
                    {tag}
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
