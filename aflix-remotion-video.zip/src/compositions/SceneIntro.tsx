import React from "react";
import { useCurrentFrame, useVideoConfig, interpolate, Easing } from "remotion";
import { BRAND, GOOGLE_FONTS_URL } from "../utils/brand";
import { fadeIn, fadeOut, slideUp, scaleFrom, growWidth, easeOutExpo } from "../utils/animations";
import { ParticleBackground } from "../components/ParticleBackground";

export const SceneIntro: React.FC = () => {
  const frame = useCurrentFrame();
  const { width, height } = useVideoConfig();

  // Timing (at 30fps, scene is 0–120 frames = 4s)
  const bgFade    = fadeIn(frame, 0, 30);
  const ringScale = scaleFrom(frame, 5, 35, 0.3, 1);
  const ringOp    = fadeIn(frame, 5, 25);
  const logoScale = scaleFrom(frame, 20, 30, 0.7, 1);
  const logoOp    = fadeIn(frame, 20, 25);
  const textOp    = fadeIn(frame, 35, 20);
  const textY     = slideUp(frame, 35, 25, 30);
  const lineW     = growWidth(frame, 55, 40, 0, 1);
  const tagOp     = fadeIn(frame, 70, 20);
  const tagY      = slideUp(frame, 70, 20, 20);

  // Exit
  const exitOp = frame > 100 ? fadeOut(frame, 100, 20) : 1;

  // Pulsing glow on logo
  const glowSize = interpolate(
    frame,
    [0, 30, 60, 90, 120],
    [0, 60, 80, 65, 70],
    { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.linear }
  );

  // Orbit rings slowly spin
  const ring1Rot = frame * 0.4;
  const ring2Rot = -frame * 0.25;
  const ring3Rot = frame * 0.15;

  return (
    <div
      style={{
        position: "absolute",
        inset: 0,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        flexDirection: "column",
        opacity: exitOp,
        background: BRAND.bg,
      }}
    >
      <style>{`@import url('${GOOGLE_FONTS_URL}');`}</style>
      <ParticleBackground opacity={bgFade} />

      {/* Orbit rings */}
      <svg
        style={{ position: "absolute", width: "100%", height: "100%", top: 0, left: 0 }}
        viewBox={`0 0 ${width} ${height}`}
      >
        {[
          { r: 180, dash: "6 12", rot: ring1Rot, op: 0.12 },
          { r: 280, dash: "3 18", rot: ring2Rot, op: 0.08 },
          { r: 380, dash: "8 20", rot: ring3Rot, op: 0.05 },
        ].map((ring, i) => (
          <ellipse
            key={i}
            cx={width / 2}
            cy={height / 2}
            rx={ring.r}
            ry={ring.r * 0.55}
            fill="none"
            stroke={BRAND.blue}
            strokeWidth={1}
            strokeDasharray={ring.dash}
            opacity={ring.op * ringOp}
            transform={`rotate(${ring.rot}, ${width / 2}, ${height / 2})`}
          />
        ))}

        {/* Corner accents */}
        {[
          [80, 80], [width - 80, 80], [80, height - 80], [width - 80, height - 80]
        ].map(([cx, cy], i) => (
          <g key={i} opacity={fadeIn(frame, 30 + i * 5, 20)}>
            <line x1={cx - 20} y1={cy} x2={cx + 20} y2={cy} stroke={BRAND.blue} strokeWidth={1.5} opacity={0.4} />
            <line x1={cx} y1={cy - 20} x2={cx} y2={cy + 20} stroke={BRAND.blue} strokeWidth={1.5} opacity={0.4} />
          </g>
        ))}
      </svg>

      {/* Logo container */}
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          opacity: logoOp,
          transform: `scale(${logoScale})`,
          position: "relative",
          zIndex: 2,
        }}
      >
        {/* Icon + wordmark row */}
        <div style={{ display: "flex", alignItems: "center", gap: 28 }}>
          {/* Logo icon */}
          <div
            style={{
              position: "relative",
              width: 100,
              height: 100,
            }}
          >
            {/* Glow */}
            <div
              style={{
                position: "absolute",
                inset: "50%",
                transform: "translate(-50%,-50%)",
                width: glowSize * 2,
                height: glowSize * 2,
                borderRadius: "50%",
                background: `radial-gradient(circle, ${BRAND.blueGlow}, transparent 70%)`,
                opacity: logoOp,
              }}
            />
            {/* Icon box */}
            <div
              style={{
                width: 100,
                height: 100,
                borderRadius: 24,
                background: `linear-gradient(135deg, ${BRAND.blue}, ${BRAND.purple})`,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                boxShadow: `0 0 40px ${BRAND.blueGlow}, inset 0 1px 0 rgba(255,255,255,0.15)`,
                position: "relative",
              }}
            >
              {/* A letterform */}
              <svg viewBox="0 0 60 60" width={54} height={54}>
                <text
                  x="50%"
                  y="78%"
                  textAnchor="middle"
                  fill="#fff"
                  fontFamily="Syne, sans-serif"
                  fontWeight={800}
                  fontSize={42}
                >
                  A
                </text>
              </svg>
            </div>
          </div>

          {/* Wordmark */}
          <div>
            <div
              style={{
                fontFamily: BRAND.fontDisplay,
                fontWeight: 800,
                fontSize: 72,
                color: BRAND.white,
                letterSpacing: -2,
                lineHeight: 1,
                opacity: textOp,
                transform: `translateY(${textY}px)`,
              }}
            >
              Aflix{" "}
              <span
                style={{
                  background: BRAND.gradMain,
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                }}
              >
                Infotech
              </span>
            </div>
          </div>
        </div>

        {/* Divider line */}
        <div
          style={{
            width: `${lineW * 520}px`,
            height: 1.5,
            background: `linear-gradient(90deg, transparent, ${BRAND.blue}, ${BRAND.purple}, transparent)`,
            marginTop: 32,
            borderRadius: 1,
          }}
        />

        {/* Tagline */}
        <div
          style={{
            fontFamily: BRAND.fontBody,
            fontWeight: 400,
            fontSize: 18,
            letterSpacing: 6,
            color: BRAND.muted,
            textTransform: "uppercase",
            marginTop: 20,
            opacity: tagOp,
            transform: `translateY(${tagY}px)`,
          }}
        >
          Software · Automation · Digital Marketing
        </div>
      </div>
    </div>
  );
};
