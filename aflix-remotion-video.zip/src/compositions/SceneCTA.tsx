import React from "react";
import { useCurrentFrame, interpolate, Easing } from "remotion";
import { BRAND, GOOGLE_FONTS_URL } from "../utils/brand";
import { fadeIn, slideUp, growWidth, scaleFrom } from "../utils/animations";
import { ParticleBackground } from "../components/ParticleBackground";

export const SceneCTA: React.FC<{ localFrame: number }> = ({ localFrame }) => {
  const f = localFrame;

  const bgOp     = fadeIn(f, 0, 30);
  const glowOp   = fadeIn(f, 10, 40);
  const tagOp    = fadeIn(f, 20, 20);
  const tagY     = slideUp(f, 20, 25, 30);
  const h1Op     = fadeIn(f, 35, 25);
  const h1Y      = slideUp(f, 35, 28, 40);
  const h2Op     = fadeIn(f, 50, 20);
  const h2Y      = slideUp(f, 50, 25, 30);
  const btnOp    = fadeIn(f, 65, 25);
  const btnScale = scaleFrom(f, 65, 25, 0.8, 1);
  const urlOp    = fadeIn(f, 80, 20);
  const lineW    = growWidth(f, 30, 50, 0, 1);
  const badgesOp = fadeIn(f, 90, 25);

  // Pulsing glow
  const pulse = Math.sin(f * 0.05) * 0.15 + 0.85;

  // Floating logo
  const floatY = Math.sin(f * 0.04) * 8;

  return (
    <div
      style={{
        position: "absolute",
        inset: 0,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        background: BRAND.bg,
        padding: "0 80px",
      }}
    >
      <style>{`@import url('${GOOGLE_FONTS_URL}');`}</style>
      <ParticleBackground opacity={bgOp} />

      {/* Big central glow */}
      <div
        style={{
          position: "absolute",
          top: "50%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          width: 700,
          height: 500,
          background: `radial-gradient(ellipse, ${BRAND.blueGlow} 0%, transparent 70%)`,
          opacity: glowOp * pulse,
          pointerEvents: "none",
        }}
      />

      {/* Floating logo icon */}
      <div
        style={{
          width: 80,
          height: 80,
          borderRadius: 20,
          background: `linear-gradient(135deg, ${BRAND.blue}, ${BRAND.purple})`,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          marginBottom: 28,
          boxShadow: `0 0 50px ${BRAND.blueGlow}, inset 0 1px 0 rgba(255,255,255,0.15)`,
          position: "relative",
          zIndex: 2,
          transform: `translateY(${floatY}px)`,
          opacity: bgOp,
        }}
      >
        <svg viewBox="0 0 60 60" width={46} height={46}>
          <text
            x="50%"
            y="78%"
            textAnchor="middle"
            fill="#fff"
            fontFamily="Syne, sans-serif"
            fontWeight={800}
            fontSize={40}
          >
            A
          </text>
        </svg>
      </div>

      {/* Tag */}
      <div
        style={{
          fontFamily: BRAND.fontBody,
          fontSize: 12,
          letterSpacing: 5,
          color: BRAND.blue,
          textTransform: "uppercase",
          marginBottom: 18,
          opacity: tagOp,
          transform: `translateY(${tagY}px)`,
          position: "relative",
          zIndex: 2,
        }}
      >
        Ready to Transform?
      </div>

      {/* Main headline */}
      <div
        style={{
          fontFamily: BRAND.fontDisplay,
          fontWeight: 800,
          fontSize: 72,
          color: BRAND.white,
          textAlign: "center",
          lineHeight: 1.05,
          letterSpacing: -2,
          opacity: h1Op,
          transform: `translateY(${h1Y}px)`,
          position: "relative",
          zIndex: 2,
          marginBottom: 8,
        }}
      >
        Build Something
      </div>
      <div
        style={{
          fontFamily: BRAND.fontDisplay,
          fontWeight: 800,
          fontSize: 72,
          textAlign: "center",
          lineHeight: 1.05,
          letterSpacing: -2,
          opacity: h2Op,
          transform: `translateY(${h2Y}px)`,
          position: "relative",
          zIndex: 2,
          marginBottom: 28,
          background: BRAND.gradMain,
          WebkitBackgroundClip: "text",
          WebkitTextFillColor: "transparent",
        }}
      >
        Extraordinary
      </div>

      {/* Divider */}
      <div
        style={{
          width: `${lineW * 320}px`,
          height: 1.5,
          background: `linear-gradient(90deg, transparent, ${BRAND.blue}, ${BRAND.purple}, transparent)`,
          marginBottom: 36,
          position: "relative",
          zIndex: 2,
        }}
      />

      {/* CTA Button */}
      <div
        style={{
          padding: "18px 52px",
          background: `linear-gradient(135deg, ${BRAND.blue}, #7c3aed)`,
          borderRadius: 50,
          fontFamily: BRAND.fontDisplay,
          fontWeight: 700,
          fontSize: 18,
          color: BRAND.white,
          letterSpacing: 0.5,
          opacity: btnOp,
          transform: `scale(${btnScale})`,
          position: "relative",
          zIndex: 2,
          marginBottom: 24,
          boxShadow: `0 0 60px ${BRAND.blueGlow}`,
        }}
      >
        Get Started with Aflix →
      </div>

      {/* URL */}
      <div
        style={{
          fontFamily: BRAND.fontBody,
          fontSize: 16,
          color: BRAND.muted,
          letterSpacing: 2,
          marginBottom: 32,
          opacity: urlOp,
          position: "relative",
          zIndex: 2,
        }}
      >
        aflix.co.in
      </div>

      {/* Badges */}
      <div
        style={{
          display: "flex",
          gap: 12,
          opacity: badgesOp,
          position: "relative",
          zIndex: 2,
        }}
      >
        {["Software Dev", "Automation", "Digital Marketing", "CRM"].map((b, i) => (
          <div
            key={i}
            style={{
              padding: "6px 16px",
              background: BRAND.bgCard,
              border: `1px solid ${BRAND.border}`,
              borderRadius: 20,
              fontFamily: BRAND.fontBody,
              fontSize: 12,
              color: BRAND.muted,
              letterSpacing: 0.5,
            }}
          >
            {b}
          </div>
        ))}
      </div>
    </div>
  );
};
