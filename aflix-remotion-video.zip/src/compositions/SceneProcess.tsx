import React from "react";
import { useCurrentFrame } from "remotion";
import { BRAND, GOOGLE_FONTS_URL } from "../utils/brand";
import { fadeIn, fadeOut, slideUp, growWidth, stagger } from "../utils/animations";
import { ParticleBackground } from "../components/ParticleBackground";

const STEPS = [
  {
    num: "01",
    icon: "🔍",
    title: "Discover",
    desc: "We deep-dive into your business, goals, and pain points to craft the perfect digital strategy.",
    color: BRAND.blue,
  },
  {
    num: "02",
    icon: "🎨",
    title: "Design",
    desc: "UX-first wireframes and prototypes that your users will love before a single line of code.",
    color: BRAND.purple,
  },
  {
    num: "03",
    icon: "⚙️",
    title: "Develop",
    desc: "Agile development with clean architecture, regular demos, and full transparency.",
    color: "#38bdf8",
  },
  {
    num: "04",
    icon: "🚀",
    title: "Deploy",
    desc: "Smooth launch, thorough testing, and ongoing support to keep your product at peak performance.",
    color: "#34d399",
  },
];

export const SceneProcess: React.FC<{ localFrame: number }> = ({ localFrame }) => {
  const f = localFrame;

  const bgOp   = fadeIn(f, 0, 25);
  const headOp = fadeIn(f, 10, 20);
  const headY  = slideUp(f, 10, 25, 30);
  const exitOp = f > 130 ? fadeOut(f, 130, 20) : 1;

  return (
    <div
      style={{
        position: "absolute",
        inset: 0,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        background: BRAND.bg,
        opacity: exitOp,
        padding: "0 80px",
      }}
    >
      <style>{`@import url('${GOOGLE_FONTS_URL}');`}</style>
      <ParticleBackground opacity={bgOp * 0.5} />

      {/* Section label */}
      <div
        style={{
          fontFamily: BRAND.fontBody,
          fontSize: 12,
          letterSpacing: 5,
          color: "#38bdf8",
          textTransform: "uppercase",
          marginBottom: 14,
          opacity: headOp,
          transform: `translateY(${headY}px)`,
          position: "relative",
          zIndex: 2,
        }}
      >
        How We Work
      </div>

      <div
        style={{
          fontFamily: BRAND.fontDisplay,
          fontWeight: 800,
          fontSize: 52,
          color: BRAND.white,
          letterSpacing: -1,
          marginBottom: 56,
          opacity: headOp,
          transform: `translateY(${headY}px)`,
          position: "relative",
          zIndex: 2,
          textAlign: "center",
        }}
      >
        Our{" "}
        <span
          style={{
            background: "linear-gradient(90deg, #38bdf8, #34d399)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
          }}
        >
          Process
        </span>
      </div>

      {/* Steps */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(4, 1fr)",
          gap: 20,
          width: "100%",
          maxWidth: 1100,
          position: "relative",
          zIndex: 2,
        }}
      >
        {/* Connector line */}
        <div
          style={{
            position: "absolute",
            top: 52,
            left: "12.5%",
            right: "12.5%",
            height: 1,
            background: `linear-gradient(90deg, ${BRAND.blue}, ${BRAND.purple}, #38bdf8, #34d399)`,
            opacity: fadeIn(f, 30, 40) * 0.3,
            zIndex: 1,
          }}
        />

        {STEPS.map((step, i) => {
          const start  = stagger(20, i, 15);
          const stepOp = fadeIn(f, start, 22);
          const stepY  = slideUp(f, start, 25, 50);
          const circleScale = (() => {
            const s = f - start;
            if (s < 0) return 0.5;
            if (s > 25) return 1;
            return 0.5 + (s / 25) * 0.5;
          })();

          return (
            <div
              key={i}
              style={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                opacity: stepOp,
                transform: `translateY(${stepY}px)`,
                position: "relative",
              }}
            >
              {/* Step circle */}
              <div
                style={{
                  width: 88,
                  height: 88,
                  borderRadius: "50%",
                  background: `radial-gradient(circle at 35% 35%, ${step.color}30, ${step.color}10)`,
                  border: `1.5px solid ${step.color}60`,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  marginBottom: 20,
                  position: "relative",
                  zIndex: 2,
                  transform: `scale(${circleScale})`,
                  boxShadow: `0 0 30px ${step.color}20`,
                }}
              >
                <span style={{ fontSize: 32 }}>{step.icon}</span>

                {/* Step number badge */}
                <div
                  style={{
                    position: "absolute",
                    top: -4,
                    right: -4,
                    width: 24,
                    height: 24,
                    borderRadius: "50%",
                    background: step.color,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontFamily: BRAND.fontDisplay,
                    fontWeight: 800,
                    fontSize: 10,
                    color: "#04060f",
                    letterSpacing: 0,
                  }}
                >
                  {i + 1}
                </div>
              </div>

              {/* Title */}
              <div
                style={{
                  fontFamily: BRAND.fontDisplay,
                  fontWeight: 700,
                  fontSize: 20,
                  color: BRAND.white,
                  marginBottom: 10,
                  textAlign: "center",
                  letterSpacing: -0.3,
                }}
              >
                {step.title}
              </div>

              {/* Desc */}
              <div
                style={{
                  fontFamily: BRAND.fontBody,
                  fontSize: 13,
                  color: BRAND.muted,
                  lineHeight: 1.65,
                  textAlign: "center",
                }}
              >
                {step.desc}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
