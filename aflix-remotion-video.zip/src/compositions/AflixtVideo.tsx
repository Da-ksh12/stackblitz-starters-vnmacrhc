import React from "react";
import { AbsoluteFill, useCurrentFrame, interpolate, Easing } from "remotion";
import { SceneIntro } from "./SceneIntro";
import { SceneServices } from "./SceneServices";
import { SceneStats } from "./SceneStats";
import { SceneProcess } from "./SceneProcess";
import { SceneCTA } from "./SceneCTA";
import { BRAND } from "../utils/brand";

// ─── Video config ─────────────────────────────────────────────────────────
export const VIDEO_FPS    = 30;
export const VIDEO_WIDTH  = 1920;
export const VIDEO_HEIGHT = 1080;

// Scene durations (frames at 30fps)
const D_INTRO    = 120;  // 4.0s
const D_SERVICES = 160;  // 5.3s
const D_STATS    = 160;  // 5.3s
const D_PROCESS  = 150;  // 5.0s
const D_CTA      = 130;  // 4.3s

// Cumulative start frames
const S_INTRO    = 0;
const S_SERVICES = S_INTRO    + D_INTRO;
const S_STATS    = S_SERVICES + D_SERVICES;
const S_PROCESS  = S_STATS    + D_STATS;
const S_CTA      = S_PROCESS  + D_PROCESS;

export const TOTAL_DURATION = S_CTA + D_CTA;  // ~720 frames = 24s

// ─── Transition helper ────────────────────────────────────────────────────
/** Smooth crossfade: 1 = fully visible, 0 = gone */
function sceneOpacity(
  frame: number,
  start: number,
  duration: number,
  fadeIn = 15,
  fadeOut = 15
): number {
  if (frame < start) return 0;
  if (frame < start + fadeIn)
    return interpolate(frame, [start, start + fadeIn], [0, 1], {
      extrapolateLeft: "clamp",
      extrapolateRight: "clamp",
      easing: Easing.bezier(0.33, 1, 0.68, 1),
    });
  if (frame > start + duration - fadeOut)
    return interpolate(frame, [start + duration - fadeOut, start + duration], [1, 0], {
      extrapolateLeft: "clamp",
      extrapolateRight: "clamp",
      easing: Easing.bezier(0.76, 0, 0.24, 1),
    });
  return 1;
}

/** Local frame within a scene */
const local = (frame: number, start: number) => Math.max(0, frame - start);

// ─── Main composition ─────────────────────────────────────────────────────
export const AflixtVideo: React.FC = () => {
  const frame = useCurrentFrame();

  return (
    <AbsoluteFill style={{ background: BRAND.bg, overflow: "hidden" }}>

      {/* ── Scene 1: Intro ─────────────────────────────────────── */}
      <AbsoluteFill
        style={{ opacity: sceneOpacity(frame, S_INTRO, D_INTRO, 20, 20) }}
      >
        <SceneIntro />
      </AbsoluteFill>

      {/* ── Scene 2: Services ──────────────────────────────────── */}
      <AbsoluteFill
        style={{ opacity: sceneOpacity(frame, S_SERVICES, D_SERVICES, 20, 20) }}
      >
        <SceneServices localFrame={local(frame, S_SERVICES)} />
      </AbsoluteFill>

      {/* ── Scene 3: Stats ─────────────────────────────────────── */}
      <AbsoluteFill
        style={{ opacity: sceneOpacity(frame, S_STATS, D_STATS, 20, 20) }}
      >
        <SceneStats localFrame={local(frame, S_STATS)} />
      </AbsoluteFill>

      {/* ── Scene 4: Process ───────────────────────────────────── */}
      <AbsoluteFill
        style={{ opacity: sceneOpacity(frame, S_PROCESS, D_PROCESS, 20, 20) }}
      >
        <SceneProcess localFrame={local(frame, S_PROCESS)} />
      </AbsoluteFill>

      {/* ── Scene 5: CTA ───────────────────────────────────────── */}
      <AbsoluteFill
        style={{ opacity: sceneOpacity(frame, S_CTA, D_CTA, 20, 10) }}
      >
        <SceneCTA localFrame={local(frame, S_CTA)} />
      </AbsoluteFill>

      {/* ── Global vignette overlay ─────────────────────────────── */}
      <AbsoluteFill
        style={{
          pointerEvents: "none",
          background:
            "radial-gradient(ellipse 110% 90% at 50% 50%, transparent 55%, rgba(4,6,15,0.65) 100%)",
        }}
      />

      {/* ── Watermark / URL ─────────────────────────────────────── */}
      <div
        style={{
          position: "absolute",
          bottom: 30,
          right: 48,
          fontFamily: "'Space Grotesk', sans-serif",
          fontSize: 14,
          color: "rgba(255,255,255,0.18)",
          letterSpacing: 2,
          zIndex: 100,
        }}
      >
        aflix.co.in
      </div>

      {/* ── Progress bar (thin line at very bottom) ──────────────── */}
      <div
        style={{
          position: "absolute",
          bottom: 0,
          left: 0,
          height: 2,
          width: `${(frame / TOTAL_DURATION) * 100}%`,
          background: `linear-gradient(90deg, ${BRAND.blue}, ${BRAND.purple})`,
          opacity: 0.5,
          zIndex: 100,
        }}
      />
    </AbsoluteFill>
  );
};
