import React from "react";
import { useCurrentFrame, interpolate, Easing } from "remotion";
import { BRAND, GOOGLE_FONTS_URL } from "../utils/brand";
import { fadeIn, fadeOut, slideUp, scaleFrom, growWidth, counter, stagger } from "../utils/animations";
import { ParticleBackground } from "../components/ParticleBackground";

const STATS = [
  { value: 50,  suffix: "+", label: "Projects\nDelivered",  color: BRAND.blue   },
  { value: 98,  suffix: "%", label: "Client\nSatisfaction", color: BRAND.purple },
  { value: 12,  suffix: "+", label: "Industries\nServed",   color: "#38bdf8"    },
  { value: 5,   suffix: "+", label: "Years of\nExperience", color: "#34d399"    },
];

const TESTIMONIAL = {
  text: '"Aflix transformed our real estate operations with a custom CRM that saved us 20+ hours per week. Truly exceptional team."',
  author: "— A Happy Client, Real Estate Sector",
};

export const SceneStats: React.FC<{ localFrame: number }> = ({ localFrame }) => {
  const f = localFrame;

  const bgOp   = fadeIn(f, 0, 25);
  const headOp = fadeIn(f, 10, 20);
  const headY  = slideUp(f, 10, 25, 30);
  const exitOp = f > 140 ? fadeOut(f, 140, 20) : 1;

  // Orbital ring rotation
  const ringRot1 = f * 0.5;
  const ringRot2 = -f * 0.3;

  return (
    <div
      style={{
        position: "absolute",
        inset: 0,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        background: BRAND.bg,
        opacity: exitOp,
        padding: "0 80px",
      }}
    >
      <style>{`@import url('${GOOGLE_FONTS_URL}');`}</style>
      <ParticleBackground opacity={bgOp * 0.5} />

      {/* Spinning orbit rings in bg */}
      <svg
        style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }}
        viewBox="0 0 1920 1080"
      >
        <ellipse
          cx={960} cy={540}
          rx={500} ry={220}
          fill="none"
          stroke={BRAND.blue}
          strokeWidth={1}
          strokeDasharray="4 16"
          opacity={0.1 * bgOp}
          transform={`rotate(${ringRot1}, 960, 540)`}
        />
        <ellipse
          cx={960} cy={540}
          rx={700} ry={310}
          fill="none"
          stroke={BRAND.purple}
          strokeWidth={0.8}
          strokeDasharray="2 20"
          opacity={0.07 * bgOp}
          transform={`rotate(${ringRot2}, 960, 540)`}
        />
      </svg>

      {/* Section label */}
      <div
        style={{
          fontFamily: BRAND.fontBody,
          fontSize: 12,
          letterSpacing: 5,
          color: BRAND.purple,
          textTransform: "uppercase",
          marginBottom: 14,
          opacity: headOp,
          transform: `translateY(${headY}px)`,
          position: "relative",
          zIndex: 2,
        }}
      >
        Our Impact
      </div>

      <div
        style={{
          fontFamily: BRAND.fontDisplay,
          fontWeight: 800,
          fontSize: 52,
          color: BRAND.white,
          letterSpacing: -1,
          marginBottom: 60,
          opacity: headOp,
          transform: `translateY(${headY}px)`,
          position: "relative",
          zIndex: 2,
          textAlign: "center",
        }}
      >
        Numbers That{" "}
        <span
          style={{
            background: "linear-gradient(90deg, #a78bfa, #38bdf8)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
          }}
        >
          Speak
        </span>
      </div>

      {/* Stats row */}
      <div
        style={{
          display: "flex",
          gap: 0,
          position: "relative",
          zIndex: 2,
          marginBottom: 60,
        }}
      >
        {STATS.map((stat, i) => {
          const start  = stagger(20, i, 15);
          const statOp = fadeIn(f, start, 22);
          const statY  = slideUp(f, start, 25, 40);
          const num    = counter(f, start, 45, stat.value);
          const barW   = growWidth(f, start + 5, 35, 0, 1);

          return (
            <div
              key={i}
              style={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                padding: "0 52px",
                opacity: statOp,
                transform: `translateY(${statY}px)`,
                borderRight: i < STATS.length - 1 ? `1px solid ${BRAND.border}` : "none",
              }}
            >
              {/* Big animated number */}
              <div
                style={{
                  fontFamily: BRAND.fontDisplay,
                  fontWeight: 800,
                  fontSize: 80,
                  lineHeight: 1,
                  marginBottom: 8,
                  background: `linear-gradient(135deg, ${BRAND.white}, ${stat.color})`,
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                }}
              >
                {num}{stat.suffix}
              </div>

              {/* Progress bar */}
              <div
                style={{
                  width: 80,
                  height: 2,
                  background: BRAND.border,
                  borderRadius: 1,
                  marginBottom: 12,
                  overflow: "hidden",
                }}
              >
                <div
                  style={{
                    height: "100%",
                    width: `${barW * 100}%`,
                    background: `linear-gradient(90deg, ${stat.color}, transparent)`,
                    borderRadius: 1,
                  }}
                />
              </div>

              {/* Label (multi-line) */}
              {stat.label.split("\n").map((line, li) => (
                <div
                  key={li}
                  style={{
                    fontFamily: BRAND.fontBody,
                    fontSize: 12,
                    letterSpacing: 2,
                    textTransform: "uppercase",
                    color: BRAND.muted,
                    lineHeight: 1.6,
                    textAlign: "center",
                  }}
                >
                  {line}
                </div>
              ))}
            </div>
          );
        })}
      </div>

      {/* Testimonial */}
      <div
        style={{
          maxWidth: 700,
          textAlign: "center",
          opacity: fadeIn(f, 80, 25),
          transform: `translateY(${slideUp(f, 80, 25, 30)}px)`,
          position: "relative",
          zIndex: 2,
          padding: "28px 36px",
          background: BRAND.bgCard,
          border: `1px solid ${BRAND.border}`,
          borderRadius: 16,
        }}
      >
        {/* Quote marks */}
        <div
          style={{
            fontFamily: BRAND.fontDisplay,
            fontSize: 64,
            color: BRAND.blue,
            opacity: 0.3,
            lineHeight: 0.5,
            marginBottom: 12,
          }}
        >
          "
        </div>
        <div
          style={{
            fontFamily: BRAND.fontBody,
            fontSize: 15,
            color: BRAND.white,
            lineHeight: 1.7,
            fontStyle: "italic",
            marginBottom: 14,
            opacity: 0.85,
          }}
        >
          {TESTIMONIAL.text.replace(/"/g, "")}
        </div>
        <div
          style={{
            fontFamily: BRAND.fontBody,
            fontSize: 12,
            color: BRAND.muted,
            letterSpacing: 1,
          }}
        >
          {TESTIMONIAL.author}
        </div>
      </div>
    </div>
  );
};
